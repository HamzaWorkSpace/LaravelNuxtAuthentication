import{DefaultConfigOptions} from "@formkit/vue";
import '@formkit/themes/genesis';

const config:DefaultConfigOptions={

};

export default config;