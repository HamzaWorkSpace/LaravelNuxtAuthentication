<template>
    <div>
        Auth Middle ware
    </div>
</template>

<script setup>

    definePageMeta({
        middleware:['auth']
    })

</script>

<style  scoped>

</style>