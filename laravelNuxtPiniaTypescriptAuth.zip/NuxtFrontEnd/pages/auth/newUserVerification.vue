<template>



        <div>
            <h1 class="font-bold text-2xl text-center mt-6"> verify your account</h1>
            <p class="text-center mt-6">    please click the link sent to you in email : EMAIL@XYZ.com  </p>
            <p class="text-center mt-6">look for email from BRAND NAME:</p>
            <p class="text-center mt-6">please also check your sspam folder</p>
            <p class="text-center mt-6">please <a href="#">click here </a> if you did not recieve Email</p>
        </div>
       
  
</template>

<script>

</script>

<style scoped>

</style>