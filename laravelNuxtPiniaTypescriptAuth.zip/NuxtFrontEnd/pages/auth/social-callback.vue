<template>
    <div class="container">
        <p>Please Wait...</p>

        {{ authStore.socialLoginToken }}

        <br/><br/><br/>

        {{authStore.socialLoginName}}     

        <br/><br/><br/>

        {{authStore.socialLoginAvatar }}

        <br/><br/><br/>

        {{authStore.isSocialLogin }}

        <br/><br/><br/>

        <img :src="authStore.socialLoginAvatar" width="200px" height="100px">
    </div>
</template>

<script setup>
    //import { onMounted } from 'vue';

    import {SanctumAuth} from '@/stores/AuthStore'

    const authStore = SanctumAuth();

    const route = useRoute();

    try{

        authStore.socialLoginToken  =   route.query.token;
        authStore.socialLoginAvatar =   route.query.avatar;
        authStore.socialLoginName   =   route.query.name;
        authStore.socialLoginemail  =   route.query.email;
        authStore.isSocialLogin     =   route.query.isSocialLogin;
        authStore.authservice       =   route.query.authservice;

        //setting token session cookie
        const socialauthToken = useCookie('socialauthToken')
        socialauthToken.value = ref(route.query.token);

        //set the above values in local storage

        // if (process.client) {
        //             window.localStorage.setItem('avatar'        , authStore.socialLoginAvatar);
        //             window.localStorage.setItem('name'          , authStore.socialLoginName);
        //             window.localStorage.setItem('email'         , authStore.socialLoginemail);
        //             window.localStorage.setItem('isSocialLogin' , authStore.isSocialLogin);
        //             window.localStorage.setItem('authservice'   , authStore.authservice);                    
        // }

        // if(authStore.isSocialLogin){// error.value==null means no error, login successfull

            await navigateTo("/", { replace: true });
        // }
        // else{
        //     await navigateTo("/auth/login", { replace: true });
        // }
    }
    catch(e) {
        await navigateTo("/auth/register?error = Your Token is Invalid,Please Try again", { replace: true });
    } 

</script>

<style scoped>

</style>