<template>
    <div>
        guest Middle ware
    </div>
</template>

<script setup>

    definePageMeta({
        middleware:['guest']
    })

</script>

<style  scoped>

</style>