<template>
  <div>
    <h1 class="font-bold text-2xl text-center mt-6">Contact us</h1>
    <p class="text-center mt-6">Email: contact@geekyshows.com</p>
  </div>
</template>

<script setup>


</script>


<style scoped>

</style>