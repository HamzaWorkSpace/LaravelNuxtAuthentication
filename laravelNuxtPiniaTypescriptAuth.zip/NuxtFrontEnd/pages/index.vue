<template>
    <div>
    
            <h2 class="text-2xl text-center my-8">All Products</h2>

            <br/> <br/> <br/>

        {{authStore.socialLoginToken}}
            <br/> <br/> <br/>
        {{authStore.socialLoginAvatar}}
        <br/> <br/> <br/>
        {{authStore.socialLoginName}}
        <br/> <br/> <br/>
        {{ authStore.socialLoginemail}} 
        <br/> <br/> <br/>
        {{authStore.isSocialLogin}}
        <br/> <br/> <br/>
        {{authStore.authservice}}   

         
      
    </div>
</template>

<script setup>

import {SanctumAuth} from '@/stores/AuthStore'
const authStore = SanctumAuth();

</script>

<style scoped>

</style>