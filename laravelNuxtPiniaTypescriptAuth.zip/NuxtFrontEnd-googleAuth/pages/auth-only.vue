<template>
    <div>
        Auth Middle ware
    </div>
</template>

<script setup>

    definePageMeta({
        middleware:['authentication']
    })

</script>

<style  scoped>

</style>