<template>
    <div>
    
            <h2 class="text-2xl text-center my-8">All Products</h2>

            <!-- {{ appStore.data }} -->
      
    </div>
</template>

<script setup>

    
    //import {useStore} from '@/stores/applicationStore'

    //const appStore = useStore();

    // appStore.dumyFunction();
</script>

<style scoped>

</style>